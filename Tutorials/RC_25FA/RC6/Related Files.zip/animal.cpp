// Check by yourself if the following implementations are correct.

#include <iostream>

class Animal {
  private:
    std::string name;
  public:
    Animal(std::string name) : name(name) {};
    virtual void speak() const = 0;
    virtual Animal* clone() const = 0;
};

class Cat : public Animal {
  public:
    Cat(std::string name) : Animal(name) {};
    void speak() const override {
        std::cout << "Meow!" << std::endl;
    }
    Animal* clone() const override {
        return new Cat(*this);
    }
};

class Dog : public Animal {
  public:
    Dog(std::string name) : Animal(name) {};
    void speak() const override {
        std::cout << "Woof!" << std::endl;
    }
    Animal* clone() const override {
        return new Dog(*this);
    }
};

struct node {
    Animal* animal;
    node* next;
    node(Animal* animal) : animal(animal), next(nullptr) {};
};

class AnimalList {
  private:
    node* head;
    void copy(node* list) {
        if (!list) return;
        copy(list->next);
        insert(list->animal->clone());
    }

  public:
    AnimalList() : head(nullptr) {};
    AnimalList(const AnimalList& list) : head(nullptr) {
        copy(list.head);
    }
    ~AnimalList() {
        node* current = head;
        while (current != nullptr) {
            node* next = current->next;
            delete current->animal;
            delete current;
            current = next;
        }
    }
    AnimalList& operator=(const AnimalList& list) {
        if (this != &list) {
            node* current = head;
            while (current != nullptr) {
                node* next = current->next;
                delete current->animal;
                delete current;
                current = next;
            }
            head = nullptr;
            copy(list.head);
        }
        return *this;
    }
    void insert(Animal* animal) {
        node* new_node = new node(animal);
        if (head == nullptr) {
            head = new_node;
        }
        else {
            node* current = head;
            while (current->next != nullptr) {
                current = current->next;
            }
            current->next = new_node;
        }
    }
    Animal* remove() {
        if (head == nullptr) {
            return nullptr;
        }
        else {
            node* current = head;
            head = head->next;
            Animal* animal = current->animal;
            delete current;
            return animal;
        }
    }
    void speak() const {
        node* current = head;
        while (current != nullptr) {
            current->animal->speak();
            current = current->next;
        }
    }
};