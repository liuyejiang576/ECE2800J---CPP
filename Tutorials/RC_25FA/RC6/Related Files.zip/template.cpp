// Check by yourself if the following implementations are correct.

#include <iostream>

template <class T>
class List {
  private:
    struct Node {
        T data;
        Node* next;
        Node(T val);
    };
    Node *first;
    void removeAll();
    void copyList (Node* np);
  public:
    bool isEmpty();
    void insert(T v);
    T remove();
    List();
    List(const List &l);
    List &operator=(const List &l);
    ~List();
};

template <class T>
List<T>::Node::Node(T val) : data(val), next(nullptr) {}

template <class T>
void List<T>::removeAll() {
    Node* current = first;
    while (current != nullptr) {
        Node* temp = current;
        current = current->next;
        delete temp;
    }
    first = nullptr;
}

template <class T>
void List<T>::copyList(Node* np) {
    if (np == nullptr) {
        first = nullptr;
        return;
    }
    first = new Node(np->data);
    Node* currentNew = first;
    Node* currentOld = np->next;
    while (currentOld != nullptr) {
        currentNew->next = new Node(currentOld->data);
        currentNew = currentNew->next;
        currentOld = currentOld->next;
    }
}

template <class T>
bool List<T>::isEmpty() {
    return first == nullptr;
}

template <class T>
void List<T>::insert(T v) {
    Node* newNode = new Node(v);
    newNode->next = first;
    first = newNode;
}

template <class T>
T List<T>::remove() {
    if (isEmpty()) {
        throw std::runtime_error("List is empty");
    }
    Node* temp = first;
    T value = first->data;
    first = first->next;
    delete temp;
    return value;
}

template <class T>
List<T>::List() : first(nullptr) {}

template <class T>
List<T>::List(const List<T> &l) {
    copyList(l.first);
}

template <class T>
List<T>::~List() {
    removeAll();
}

template <class T>
List<T> &List<T>::operator=(const List<T> &l) {
    if (this != &l) {
        removeAll();
        copyList(l.first);
    }
    return *this;
}