#include "intSet.h"

const int MAXELTS = 100;

class IntSetImpl: public IntSet { // OVERVIEW omitted for space
    int elts[MAXELTS];
    int numElts;
    int indexOf(int v); // RME omitted for space
public:
    IntSetImpl();
    void insert(int v); // RME omitted for space
    void remove(int v); // RME omitted for space
    bool query(int v);  // RME omitted for space
    int  size(); 
};


IntSetImpl::IntSetImpl():
  numElts(0)
{}

int IntSetImpl::size() {
  return numElts;
}

int IntSetImpl::indexOf(int v) {
  for (int i = 0; i < numElts; i++) {
    if (elts[i] == v) return i;
  }
  return MAXELTS;
}

bool IntSetImpl::query(int v)     {
  return (indexOf(v) != MAXELTS);
}

void IntSetImpl::insert(int v) {
  if (indexOf(v) == MAXELTS) {
    if (numElts == MAXELTS) throw MAXELTS; 
    elts[numElts++] = v;
  }
}

void IntSetImpl::remove(int v) {
  int victim = indexOf(v);
  if (victim != MAXELTS) {
    elts[victim] = elts[numElts-1];
    numElts--;
  }
}

static IntSetImpl impl;
IntSet *getIntSet() {
  return & impl;
}

