#include "intSet.h"
#include <iostream>

int main(){
  IntSet *is = getIntSet();
  for (int i = 0; i < 10; i++){
    is->insert(i);
  }
  std::cout << " IntSet size = " << is->size() << std::endl;
  for (int i = 0; i < 10; i++){
    is->remove(i);
  }
  std::cout << " IntSet size = " << is->size() << std::endl;
  return 0;
};
