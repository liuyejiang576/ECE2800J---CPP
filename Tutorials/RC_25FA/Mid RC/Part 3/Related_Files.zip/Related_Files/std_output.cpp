#include <iostream>
#include <thread>
#include <chrono>

int main() {
    // 1. output with '\n' (may not flush immediately)
    std::cout << "Test 1: Output with '\\n'\n";
    std::cout << "(This line uses '\\n'. If you see this immediately, \\n likely triggered a flush.)\n";

    // Pause for 5 seconds
    std::cout << "Pausing for 5 seconds... (Check if above lines are visible NOW)\n";
    std::this_thread::sleep_for(std::chrono::seconds(5));

    // 2. output with std::endl (forces flush, for comparison)
    std::cout << "Test 2: Output with 'std::endl'" << std::endl;
    std::cout << "(This line uses 'std::endl'. This WILL be flushed immediately.)" << std::endl;

    std::cout << "Pausing for another 5 seconds..." << std::endl;
    std::this_thread::sleep_for(std::chrono::seconds(5));

    // 3. output with std::flush
    std::cout << "Test 3: Output with '\\n' followed by std::flush\n";
    std::cout << "(This demonstrates explicit flushing.)" << std::flush;

    std::cout << " ...and now with std::endl" << std::endl;

    std::cout << "Program finished." << std::endl;
    return 0;
}