#include <iostream>
#include <string>
int main() {
    int age;
    std::string name;
    std::cout << "Enter your age: ";
    std::cin >> age;
    std::cout << "Enter your name: ";
    // std::cin.get();
    // std::cin.ignore();
    std::getline(std::cin, name);
    std::cout << "Age: " << age << ", Name: '" << name << "'" << std::endl;
    return 0;
}
