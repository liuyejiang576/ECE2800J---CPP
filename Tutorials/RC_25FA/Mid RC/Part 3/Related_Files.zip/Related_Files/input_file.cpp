#include <iostream>
#include <string>
#include <fstream>
int main() {
    std::ifstream infile("std_input.txt");
    // std::ofstream outfile("std_output.txt");
    // std::ofstream outfile("std_output.txt", std::ios::out); // same as above
    std::ofstream outfile("std_output.txt", std::ios::app); // append mode
    std::string str;

    while (std::getline(infile, str)) {
        outfile << str << std::endl;
    }
    infile.close();

    // infile.open("std_in.txt");
    infile.open("std_in.txt", std::ios::in); // same as above
    while (std::getline(infile, str)) {
        outfile << str << std::endl;
    }

    infile.close();
    outfile.close();

    std::fstream fstr;
    fstr.open("std_fstream.txt", std::ios::in | std::ios::trunc | std::ios::out);
    fstr << "It is fstream." << std::endl;
    fstr.seekg(0); // Move read pointer to the beginning
    std::getline(fstr, str);
    std::cout << "Read from fstream: " << str << std::endl;
    fstr.close();
    return 0;
}