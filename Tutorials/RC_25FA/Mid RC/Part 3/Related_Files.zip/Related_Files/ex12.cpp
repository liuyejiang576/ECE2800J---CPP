#include <iostream>
void bar(double x){
    throw x;
    try{
        throw x;
    }
    catch(double a){
        std::cout << "double in bar\n";
    }
    std::cout << "exit bar\n";
}
void foo(int x){
    try {
        bar(x);
    }
    catch(int a){
        std::cout << "int in foo\n";
    }
    catch(double b){
        std::cout << "double in foo\n";
    }
    std::cout << "exit foo\n";
}
int main(){
    int x = 6;
    foo(x);
}