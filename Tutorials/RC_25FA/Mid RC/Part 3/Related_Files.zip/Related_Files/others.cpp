#include <iostream>
#include <string>
#include <cstdlib>
int main(int argc, char* argv[]) {
    int v1 = std::stoi(argv[1]); // <string>, 'std::' is necessary
    int v2 = atoi(argv[2]); // <cstdlib>, 'std::' optional
    int v3 = std::atoi(argv[3]); // <cstdlib>
    std::cout << "The first value is: " << v1 << std::endl;
    std::cout << "The second value is: " << v2 << std::endl;
    std::cout << "The third value is: " << v3 << std::endl;
    return 0;
}