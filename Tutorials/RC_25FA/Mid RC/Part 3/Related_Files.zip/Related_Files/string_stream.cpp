#include <sstream>
#include <string>
#include <iostream>
int main(){
    std::istringstream is;
    std::ostringstream os;
    std::string foo;
    int bar;
    std::string s = "ECE 2800J";
    is.str(s);
    is >> foo >> bar;
    os << foo << bar;
    s = os.str();
    std::cout << s << std::endl;
    // std::stringstream ss;
    // ss << "Number: " << 42 << ", String: " << "Hello";
    // ss.clear();
    // ss.str("");
    return 0;
}