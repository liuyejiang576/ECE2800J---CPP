#include <iostream>
using namespace std;

struct MyException {
    string msg;
    
    MyException(const string& s) : msg(s) {
        cout << "构造: " << msg << endl;
    }
    
    MyException(const MyException& other) : msg("copy of " + other.msg) {
        cout << "拷贝构造: " << msg << endl;
    }
    
    ~MyException() {
        cout << "析构: " << msg << endl;
    }
};

int main() {
    try {
        throw MyException("Original");
    }
    catch (MyException t) {  // 按值捕获
        cout << "捕获到: " << t.msg << endl;
    }
}