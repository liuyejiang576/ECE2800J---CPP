#include <iostream>

class SimpleClass {
  private:
    int value;
  public:
    SimpleClass(int v) : value(v) {
        std::cout << "Constructor called." << std::endl;
    }
    int getValue() const {
        return value;
    }
    void setValue(int v) {
        value = v;
    }
    SimpleClass operator+(const SimpleClass& other) {
        std::cout << "Member + called." << std::endl;
        return SimpleClass(value + other.value);
    }
    SimpleClass operator+(const int& other) {
        std::cout << "Member int + called." << std::endl;
        return SimpleClass(value + other);
    }
    SimpleClass& operator=(const SimpleClass& other) {
        std::cout << "Assignment = called." << std::endl;
        value = other.value;
        return *this;
    }
};

SimpleClass operator+(const SimpleClass& lhs, const SimpleClass& rhs) {
    std::cout << "Non-member + called." << std::endl;
    return SimpleClass(lhs.getValue() + rhs.getValue());
}

SimpleClass operator+(const SimpleClass& lhs, const int& rhs) {
    std::cout << "Non-member int + called." << std::endl;
    return SimpleClass(lhs.getValue() + rhs);
}

SimpleClass operator+(const int& lhs, const SimpleClass& rhs) {
    std::cout << "Non-member left int + called." << std::endl;
    return SimpleClass(lhs + rhs.getValue());
}

// SimpleClass operator+(const int& lhs, const int& rhs) {
//     std::cout << "Non-member left int + called." << std::endl;
//     return SimpleClass(lhs + rhs);
// }

int main() {
    SimpleClass obj(10);
    std::cout << "obj Value: " << obj.getValue() << std::endl;
    const SimpleClass obj2(5);
    SimpleClass obj3 = obj2 + obj;
    std::cout << "obj3 Value: " << obj3.getValue() << std::endl;
    SimpleClass obj4 = obj + 20;
    std::cout << "obj4 Value: " << obj4.getValue() << std::endl;
    SimpleClass obj5 = obj2 + 20;
    std::cout << "obj5 Value: " << obj5.getValue() << std::endl;
    SimpleClass obj6 = 25 + obj2;
    std::cout << "obj6 Value: " << obj6.getValue() << std::endl;
    return 0;
}