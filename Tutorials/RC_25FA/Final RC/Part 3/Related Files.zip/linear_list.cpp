// Check by yourself if the following content is correct

#include<iostream>

class BoundsError {};

struct ListNode {
    int val;
    ListNode* next;
    ListNode(int x) : val(x), next(NULL) {}
};

class LinkedList {
    ListNode* head;
    int size;
  public:
    LinkedList() : head(NULL), size(0) {}
    void insert(int i, int v) {
        if (i < 0 || i > size)
            throw BoundsError();
        ListNode* newNode = new ListNode(v);
        if (i == 0) {
            newNode->next = head;
            head = newNode;
        } else {
            ListNode* prev = head;
            for (int j = 0; j < i - 1; ++j) {
                prev = prev->next;
            }
            newNode->next = prev->next;
            prev->next = newNode;
        }
        ++size;
    }
    void remove(int i) {
        if (i < 0 || i >= size)
            throw BoundsError();
        ListNode* toDelete;
        if (i == 0) {
            toDelete = head;
            head = head->next;
        } else {
            ListNode* prev = head;
            for (int j = 0; j < i - 1; ++j) {
                prev = prev->next;
            }
            toDelete = prev->next;
            prev->next = toDelete->next;
        }
        delete toDelete;
        --size;
    }
};