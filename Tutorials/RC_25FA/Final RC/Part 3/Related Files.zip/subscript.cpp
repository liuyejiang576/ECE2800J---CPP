#include <iostream>

class complex {
  private:
    double real;
    double imag;
  public:
    complex(double r = 0, double i =0) : real(r), imag(i) {}
    const double &operator[](int index) const {
        std::cout << "const version called" << std::endl;
        if (index == 0) return real;
        else if (index == 1) return imag;
        else throw std::out_of_range("Index out of range");
    }
    double &operator[](int index) {
        std::cout << "non-const version called" << std::endl;
        if (index == 0) return real;
        else if (index == 1) return imag;
        else throw std::out_of_range("Index out of range");
    }
};

int main(){
    complex c1(1.0, 2.0);           // non const object
    const complex c2(3.0, 4.0);     // const object

    // non const object → call non-const version
    double a = c1[0];               // output: non-const version called
    const double b = c1[1];         // output: non-const version called
    c1[1] = 99;                     // output: non-const version called

    // const object → call const version
    double c = c2[0];               // output: const version called
    const double d = c2[1];         // output: const version called
    // c2[1] = 88;                  // compile error! const version returns const double&

    // access non-const object through const reference → call const version!
    const complex& ref = c1;
    double e = ref[0];              // output: const version called

    // access non-const object through pointer to const → call const version!
    const complex* p = &c1;
    double f = (*p)[1];             // output: const version called

    // access non-const object through const pointer → call non-const version!
    complex* const q = &c1;
    double g = (*q)[0];             // output: non-const version called

    // access non-const object through const pointer to const → call non-const version!
    const complex* const r = &c1;
    double h = (*r)[1];             // output: const version called

    double &ref2 = c1[1];           // output: non-const version called
    ref2 = 77.1;                    // not a good practice, but valid
    std::cout << "c1.imag = " << c1[1] << std::endl;
    return 0;
}
