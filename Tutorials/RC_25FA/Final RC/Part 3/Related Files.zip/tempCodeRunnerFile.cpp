    SimpleClass(const SimpleClass& other) : value(other.value) {
        std::cout << "Copy constructor called." << std::endl;
    }