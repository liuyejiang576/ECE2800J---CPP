#include <iostream>

class SimpleClass {
  private:
    int value;
  public:
    SimpleClass(int v) : value(v) {}
    SimpleClass(const SimpleClass& other) : value(other.value) {
        std::cout << "Copy constructor called." << std::endl;
    }
    int getValue() const {
        return value;
    }
    void setValue(int v) {
        value = v;
    }
    SimpleClass& operator+=(const SimpleClass& other) {
        value += other.value;
        return *this;
    }
    SimpleClass& operator+=(const int& other) {
        value += other;
        return *this;
    }
    // SimpleClass& operator=(const SimpleClass& other) {
    //     std::cout << "Assignment operator called." << std::endl;
    //     if (this != &other) {
    //         value = other.value;
    //     }
    //     return *this;
    // }
};

// SimpleClass& operator+=(SimpleClass& lhs, const SimpleClass& rhs) {
//     lhs.setValue(lhs.getValue() + rhs.getValue());
//     return lhs;
// }

// SimpleClass& operator=(SimpleClass& lhs, const SimpleClass& rhs) {
//     lhs.setValue(rhs.getValue());
//     return lhs;
// }

int main() {
    SimpleClass obj(10);
    std::cout << "Initial Value: " << obj.getValue() << std::endl;
    SimpleClass obj2 = obj;
    obj2 = obj;
    obj2 += 5;
    obj2 += obj;
    std::cout << "Updated Value: " << obj2.getValue() << std::endl;
    return 0;
}