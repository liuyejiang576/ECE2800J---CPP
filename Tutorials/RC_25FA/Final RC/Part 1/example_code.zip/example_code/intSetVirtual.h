class IntSetVirtual { // OVERVIEW omitted for space
public:
    virtual void insert(int v) = 0; // RME omitted for space
    virtual void remove(int v) = 0; // RME omitted for space
    virtual bool query(int v) = 0;  // RME omitted for space
    virtual int  size() = 0; 
};

IntSetVirtual *getIntSet();