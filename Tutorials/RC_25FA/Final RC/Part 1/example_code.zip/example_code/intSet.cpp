# include "intSet.h"

// Private member function
int IntSet::indexOf(int v) {
    for (int i = 0; i < numElts; i++) {
        if (elts[i] == v) return i;
    }
    return MAX_ELTS;
}

// Initialization list
IntSet::IntSet() : elts{0}, numElts(0) {}

// Public member functions
void IntSet::insert(int v) {
    if (indexOf(v) == MAX_ELTS) {
        if (numElts == MAX_ELTS) throw MAX_ELTS;
        elts[numElts++] = v;
    }
}

void IntSet::remove(int v) {
    int victim = indexOf(v);
    if (victim != MAX_ELTS) {
        elts[victim] = elts[numElts-1];
        numElts--;
    }
}

bool IntSet::query(int v) const {
    for (int i = 0; i < numElts; ++i) {
        if (elts[i] == v) return true;
    }
    return false;
}

int IntSet::size() const {
    return numElts;
}
