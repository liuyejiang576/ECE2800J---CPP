#include "intSet.h"

class MaxIntSet : public IntSet {
    // OVERVIEW: a set of integers,
    // where |set| <= 100
public:
    int max();
        // REQUIRES: set is non-empty.
        // EFFECTS: returns largest element in set.
};