const int MAX_ELTS = 100;

// OVERVIEW: a mutable set of integers
class IntSet {
private:
    int elts[MAX_ELTS];
    int numElts;
    int indexOf(int v);

public:
    IntSet();
        // default constructor
    void insert(int v);
        // MODIFIES: this
        // EFFECTS: this = this + {v}
    void remove(int v);
        // REQUIRES: v in the set
        // MODIFIES: this
        // EFFECTS: this = this - {v} if v in this
    bool query(int v) const;
        // EFFECTS: returns true if v in this
    int size() const;            
        // EFFECTS: returns |this|
};